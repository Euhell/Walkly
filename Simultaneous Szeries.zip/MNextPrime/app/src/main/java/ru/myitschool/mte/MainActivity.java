package ru.myitschool.mte;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import ru.myitschool.mte.databinding.ActivityMainBinding;

public class MainActivity extends AppCompatActivity {

    private ActivityMainBinding binding;
    private final String EXTRA_KEY = "long number";
    private String currentNumber = NumUtils.mockedNumber;
    Button button;
    TextView tv;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        tv = findViewById(R.id.result);
        button = findViewById(R.id.compute);

        Intent intent = getIntent();
        if (intent != null && intent.getExtras() != null) {
            String number = intent.getExtras().getString(EXTRA_KEY);
            if (number != null) {
                currentNumber = number;
            }
        }

        tv.setText(".");
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                f();
            }
        });

    }

    public void f() {
        tv.setText("..");
        new Thread(new Runnable() {
            @Override
            public void run() {
                final String nextPrime = NumUtils.nextPrime(currentNumber);
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        tv.setText(nextPrime);
                    }
                });
            }
        }).start();
    }
}
